/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testcalc;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author dafrebal
 */
public class FXMLDocumentController implements Initializable {
    private double aux1=0,aux=0;
    private int lastOp=0;

    @FXML
    private Label label;
    @FXML
    private TextField text;
    @FXML
    private Button delete;
    private Button div;
    private Button mult;
    
    @FXML
    private void deleteButton(ActionEvent event) {
        text.setText("");
        aux1=0;
        lastOp=0;

    }
    @FXML
    private void printNumber(ActionEvent event){
        text.setText(text.getText()+((Button)event.getSource()).getText());
    }
    @FXML 
    private void operand(ActionEvent event){
        String op=((Button)event.getSource()).getText();
        switch(op){
            case "+":   aux1+=Double.parseDouble(text.getText());
                        text.setText("");
                        lastOp=1;
                        break;
            case "-":   if(aux1==0){aux1+= Double.parseDouble(text.getText());}
                        else aux1-=Double.parseDouble(text.getText());
                        text.setText("");
                        lastOp=2;
                        break;
            case "X":   if(aux1!=0){aux1*=Double.parseDouble(text.getText());}
                        else aux1=1*Double.parseDouble(text.getText());
                        text.setText("");
                        lastOp=3;
                        break;
            case "/":   aux=Double.parseDouble(text.getText());
                        if(aux==0.0){text.setText("NaN");}
                        else {
                            aux1=aux;
                            text.setText("");
                            lastOp=4;
                        }
                        break;
            case ".":   text.setText(text.getText()+".");
                        break;
            case "=":   switch(lastOp){
                            case 0: if(!text.getText().equals("")){aux1=Double.parseDouble(text.getText());}
                                    else aux1=0;
                                    break;
                            case 1: aux1+=Double.parseDouble(text.getText());
                                    break;
                            case 2: aux1-=Double.parseDouble(text.getText());
                                    break;
                            case 3: aux1*=Double.parseDouble(text.getText());
                                    break;
                            case 4: aux=Double.parseDouble(text.getText());
                                    if(aux==0){text.setText("NaN");}
                                    else aux1=aux1/aux;
                        }
                        text.setText(Double.toString(aux1));
                        aux1=0;
                        break;
        }
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
